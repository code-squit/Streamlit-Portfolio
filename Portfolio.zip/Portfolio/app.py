import streamlit as st
from PIL import Image
navigations_list =['About', 'Projects', 'Resume','Technical Skills', 'Work Experience','Certifications',"Contact"]
nav = st.sidebar.radio("You can navigate to",navigations_list)

if nav =='About':
    st.markdown("<h1 style='text-align: center; color:orange;'>About Me</h1>", unsafe_allow_html=True)
    st.subheader('''An Applied Statistics Master's holder ,I would like to start my career as a Data Scientist.To enhance my skills in the respective subjects,started training  at the Innomatics Research Labs in Hyderabad.''')
    st.markdown("<h2 style='text-align: center; color:violet;'>My time line</h2>", unsafe_allow_html=True)
    st.subheader('**_2 Jul_ 1997**')
    st.write('landed on the earth:cake: ')
    st.subheader('**_march_ 2012**')
    st.write('Completed SSC')
    st.subheader('**_may_ 2014**')
    st.write('Completed my intermediate')
    st.subheader('**_may 2014 -may_ 2015**')
    st.write('Education gap due to health issues')
    st.subheader('**_Apr_ 2018**')
    st.write('Completed my Graduation')
    st.subheader('**_nov_ 2020**')
    st.write('Completed my post Graduation')
    st.subheader('**_sep_ 2021 to till date**')
    st.write('Started training in Data Sciene course at Innomatics Research Labs')
    st.subheader('')
elif nav =='Projects':
    st.markdown("<h1 style='text-align: center; color:orange;'>Training Projects</h1>", unsafe_allow_html=True)
    st.subheader('1. Web Scraping - Cars24.com')
    st.markdown('''
    1. Data is scraped from the official website with the help of python libraries "request" and"BeautifulSoup".                         
    2. Data is cleaned and exploratory data analysis performed.                                           
    3. Location wise statistical analysis is performed.          
    3. The best cars are selected based on their brand,price and year.''')
    st.subheader('2.URL shortner')
    st.write('''
    1. Made a URL Shortener that shorten the original URL,through that shorten URLthe user will be re-directed to the original URL page.                                                                                                                                                                         
    2. Used Flask for the back end along with HTML and CSS for the front end and SQLAlchemy for the data base purpose.                                                                                            
    3. When the user press submit button, through the POST request the data is transmitted to the backend where it is shortened, along with that, original URL with its shortened URL is stored in the Data Base.       
    4. Through that shortened URL the user will be re-directed to the original URL and the same shorten URL can also be use in future for re-direction.''')                                                                                                                           
    st.markdown("<h1 style='text-align: center; color: violet;'>Academic Projects</h1>", unsafe_allow_html=True)
    st.subheader('1.Sentiment analysis - New Education Policy in india')
    st.markdown('''
    1. This project is about extracting the sentiment by processing the tweets from Twitter.                                                            
    2. An algorithm has been developed to obtained the sentiment score of the extracted tweets using Twitter API.
    3. The results has shown that the new education policy has a positive sentiment                                                             
       ''')
    st.subheader('2. Machine Learning - modelling of Water bodies in USA')
    st.markdown('''
    1. This project is about the statistical modeling of water bodies in US using the dataset obtained from the UCI repository. 
    2. A detailed descriptive statistical model has been developed and various models have been compared.
       ''')
elif nav =='Resume':
    image = Image.open('Saipriya_Resume.jpg')
    st.image(image, caption='My Resume')
elif nav =='Technical Skills':
    st.markdown("<h1 style='text-align: center; color:orange;'>Technical Skills</h1>", unsafe_allow_html=True)
    st.subheader('Programming languages:')
    st.markdown('''
        1. Python  
        2. HTML
        3. Tableau
        4. Excel
        5. Flask frame work
        6. Streamlit
        ''')
    st.subheader('Data Analysis :')
    st.write('''
    1. Data Frame creation
    2. Data cleaning 
    3. Exploratory Data Analysis
    ''')
elif nav =='Work Experience':
    st.markdown("<h1 style='text-align: center; color: blue;'>Work Experience</h1>", unsafe_allow_html=True)
    st.subheader('Data Science Intern at Innomatics Research Labs')
    st.markdown(''' 
    1. Here I learnt python advance.                                 
    2. Upskilled in Statistics.
    3. learnt front end tools like html,css and back end applications like flask,streamlit.
    4. worked on major projects on flask frame work ,web scraping and streamlit portfolio.                     
    5. Developed my communication skills 
    ''')
    
elif nav =='Certifications':
        col1,col2=st.columns(2)
        with col1:
                image = Image.open('hackathon_certificate.jpg')
                st.image(image, caption='Hackthon participation certificate')
        with col2:
                image = Image.open('Saipriya.jpg')
                st.image(image, caption='Data Analysis Course certificate')
elif nav=='Contact':
    st.subheader("Mobile:")
    st.write('+91 - 9010286654')
    st.subheader('E-mail:')
    st.markdown('saipryarangapuri@gmail.com')
    st.subheader('Github')
    st.markdown('https://github.com/SaiPriya-R')
    st.subheader('LinkedIn')
    st.markdown('https://linkedin.com/in/sai-priya-b612b41b7')
phooto =st.sidebar.image('photo-sai.jpg',width =320,caption = 'SaiPriya Rangapuri')
st.sidebar.subheader('Name : SaiPriya Rangapuri')
st.sidebar.markdown('''              
Qualification: Master of Science               
Specialization : Applied Statistics            
''')
st.sidebar.subheader('Thank you for taking time to view my portfolio.')